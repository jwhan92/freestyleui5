sap.ui.define([
    "./BaseController",
    "sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter"
], function (BaseController, MessageBox, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("freestyle9999.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy : true,
					delay : 0
				});

            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
            this.getRouter().getRoute("create").attachPatternMatched(this._onCreateMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
					// Restore original busy indicator delay for the object view
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				}
            );
            
            sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
            this.aRequiredInputs = ["BusinessPartnerInput"];
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */


		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
        onSave: function () {
            //mandatory check
            if (!this._validateFormInput()) {
                return;
            }

            if (!this._busyDialog) {
                this._busyDialog = new sap.m.BusyDialog("busyDialog", {
                    title: "Process",
                    text: "Sending data ..."
                });
                this.getView().addDependent(this._busyDialog);
            }
            this._busyDialog.open();
            var that = this;

            var sEditMode = this._editMode;
            var oData = this.getView().getBindingContext().getObject();
            delete oData.__metadata;
            var sPath = this.getView().getBindingContext().getPath();
            var oModel = this.getModel();

            if (sEditMode === "update") {
                oModel.update(sPath, oData, {
                    success: function (result) {
                        MessageBox.success("Update successful!");
                        that.getModel().refresh();
                        that._busyDialog.close();
                        that.byId("BusinessPartnerInput").setEditable(false);
                        that.byId("CreatedAtInput").setEditable(false);
                    },
                    error: function (err) {
                        that._showError("Update failed!", err);
                    }
                });
            }
            if (sEditMode === "create") {
                oModel.create("/BusinessPartner", oData, {
                    success: function (result) {
                        MessageBox.success("Creation successful!");
                        that._busyDialog.close();
                        that.byId("saveBtn").setEnabled(false);
                        that.byId("BusinessPartnerInput").setEditable(false);
                        that.byId("CreatedAtInput").setEditable(false);
                    },
                    error: function (err) {
                        that._showError("Creation failed!", err);

                    }
                });
            }
        },
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched : function (oEvent) {
            this._editMode = "update";
            this.byId("saveBtn").setEnabled(true);
            this.byId("BusinessPartnerInput").setEditable(false);
            this.byId("CreatedAtInput").setEditable(false);

            var sObjectId =  oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then( function() {
				var sObjectPath = this.getModel().createKey("BusinessPartner", {
					BusinessPartner :  sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView : function (sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange : function () {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.BusinessPartner,
				sObjectName = oObject.BusinessPartner;

			oViewModel.setProperty("/busy", false);

			oViewModel.setProperty("/shareSendEmailSubject",
			oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
			oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
        },
        _showError: function (msg, err) {

            var message = "";
            if (err.responseText) {
                var oResponse = JSON.parse(err.responseText);
                if (oResponse.error && oResponse.error.message) {
                    message = oResponse.error.message;
                }
            }
            MessageBox.error(msg + "\n" + message.value);
            this._busyDialog.close();
        },
        _validateFormInput: function () {
            var isValid = true;
            sap.ui.getCore().getMessageManager().removeAllMessages();

            var oBusinessPartnerInput = this.byId("BusinessPartnerInput");

            var aInputs = [];
            var msgBPValidate = this.getResourceBundle().getText("msgBPValidate");
            aInputs.push({ input: oBusinessPartnerInput, message: msgBPValidate });

            aInputs.forEach(function (oData) {
                var oInput = oData.input;
                var sMessage = oData.message;
                oInput.setValueState(sap.ui.core.ValueState.None);
                oInput.setValueStateText("");

                if (!oInput.getValue()) {
                    //clear value state for plant and material
                    oInput.setValueState(sap.ui.core.ValueState.Error);
                    oInput.setValueStateText(sMessage);
                    isValid = false;
                }
            }, this);

            return isValid;
        },
        _clearErrorMsg: function () {
            var that = this;
            this.aRequiredInputs.forEach(function (oData) {
                var oInput = that.byId(oData);
                oInput.setValueState(sap.ui.core.ValueState.None);
                oInput.setValueStateText("");
            });
        },
        _onCreateMatched: function (oEvent) {
            this._clearErrorMsg();
            this._editMode = "create";
            this.byId("saveBtn").setEnabled(true);
            this.byId("BusinessPartnerInput").setEditable(true);
            this.byId("CreatedAtInput").setEditable(true);
            var sContext = this.getModel().createEntry("/BusinessPartner").getPath();
            this._bindView(sContext);
        }
	});

});